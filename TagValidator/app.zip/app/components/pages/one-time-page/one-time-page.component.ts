import { Component,Input  } from '@angular/core';


@Component({
  selector: 'one-time-page',
  template:  `<one-time-scan></one-time-scan>`
})

export class OneTimPageComponent implements Input { 



}