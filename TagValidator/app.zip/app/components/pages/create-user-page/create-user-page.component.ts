import { Component } from '@angular/core';

@Component({
  selector: 'create-user-page',
  template:  `<create-user></create-user>`,
})

export class CreateUserPageComponent  { }