import { Component } from '@angular/core';

@Component({
  selector: 'single-info-page',
  template:  `<single-info></single-info>`
})

export class SingleInfoPageComponent  {}