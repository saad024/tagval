import { Component } from '@angular/core';

@Component({
  selector: 'user-management-page',
  template:  `<user-management></user-management>`
})

export class UserManagementPageComponent  {}