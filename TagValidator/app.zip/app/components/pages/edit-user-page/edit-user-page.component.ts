import { Component } from '@angular/core';

@Component({
  selector: 'edit-user-page',
  template:  `<edit-user></edit-user>`,
})

export class EditUserPageComponent  {}