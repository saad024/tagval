import { Component } from '@angular/core';

@Component({
  selector: 'create-scan-page',
  template:  `<create-scan></create-scan>`,
})

export class CreatePageComponent  {}
