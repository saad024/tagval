"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var MonitorChartComponent = (function () {
    function MonitorChartComponent() {
        this.chartData = [];
        this.progressDesc = '0%';
        this.progressClass = 'c100 big p0';
        this.progressDesc_2 = '0%';
        this.progressClass_2 = 'c100 big p0';
        this.pct2 = 0;
        this.pct1 = 0;
    }
    MonitorChartComponent.prototype.display_pct1 = function (p) {
        this.progressDesc = p + '%';
        this.progressClass = 'c100 big p' + p;
    };
    MonitorChartComponent.prototype.update_pct1 = function () {
        var _this = this;
        this.display_pct1(this.pct1++);
        if (this.pct1 <= 75) {
            setTimeout(function () { _this.update_pct1(); }, 1 * this.pct1);
        }
    };
    MonitorChartComponent.prototype.display_pct2 = function (p) {
        this.progressDesc_2 = p + '%';
        this.progressClass_2 = 'c100 big p' + p;
    };
    MonitorChartComponent.prototype.update_pct2 = function () {
        var _this = this;
        this.display_pct2(this.pct2++);
        if (this.pct2 <= 50) {
            setTimeout(function () { _this.update_pct2(); }, 1 * this.pct2);
        }
    };
    MonitorChartComponent.prototype.ngOnInit = function () {
        this.update_pct1();
        this.update_pct2();
        // console.log(this.chartData.length);
    };
    return MonitorChartComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], MonitorChartComponent.prototype, "chartData", void 0);
MonitorChartComponent = __decorate([
    core_1.Component({
        selector: 'monitor-chart',
        templateUrl: 'app/components/monitor-chart/monitor-chart.component.html',
        styleUrls: ['app/components/monitor-chart/monitor-chart.component.css',
            'app/css/circle.css']
    }),
    __metadata("design:paramtypes", [])
], MonitorChartComponent);
exports.MonitorChartComponent = MonitorChartComponent;
//# sourceMappingURL=monitor-chart.component.js.map