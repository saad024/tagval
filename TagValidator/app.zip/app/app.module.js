"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var http_1 = require("@angular/http");
require("./rxjs-extensions");
var app_component_1 = require("./app.component");
var create_scan_component_1 = require("./components/create-scan/create-scan.component");
var header_component_1 = require("./components/header/header.component");
var one_time_scan_component_1 = require("./components/one-time-scan/one-time-scan.component");
var single_info_component_1 = require("./components/single-info/single-info.component");
var user_management_component_1 = require("./components/user-management/user-management.component");
var create_user_component_1 = require("./components/create-user/create-user.component");
var edit_user_component_1 = require("./components/edit-user/edit-user.component");
var monitor_chart_component_1 = require("./components/monitor-chart/monitor-chart.component");
var monitor_graph_component_1 = require("./components/monitor-graph/monitor-graph.component");
var dropdown_url_component_1 = require("./components/dropdown-url/dropdown-url.component");
var dropdown_search_component_1 = require("./components/dropdown-search/dropdown-search.component");
var dropdown_check_component_1 = require("./components/dropdown-checks/dropdown-check.component");
var create_scan_page_component_1 = require("./components/pages/create-scan-page/create-scan-page.component");
var one_time_page_component_1 = require("./components/pages/one-time-page/one-time-page.component");
var single_info_page_component_1 = require("./components/pages/single-info-page/single-info-page.component");
var user_management_page_component_1 = require("./components/pages/user-management-page/user-management-page.component");
var edit_user_page_component_1 = require("./components/pages/edit-user-page/edit-user-page.component");
var create_user_page_component_1 = require("./components/pages/create-user-page/create-user-page.component");
var monitoring_page_component_1 = require("./components/pages/monitoring-page/monitoring-page.component");
var table_api_service_1 = require("./services/table-api.service");
var auth_service_1 = require("./services/auth.service");
var app_routing_module_1 = require("./app-routing.module");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [
            platform_browser_1.BrowserModule,
            app_routing_module_1.AppRoutingModule,
            forms_1.FormsModule,
            http_1.HttpModule,
            http_1.JsonpModule
        ],
        declarations: [
            app_component_1.AppComponent,
            create_scan_component_1.CreateScanComponent,
            header_component_1.HeaderComponent,
            one_time_scan_component_1.OneTimeScanComponent,
            single_info_component_1.SingleInfoComponent,
            user_management_component_1.UserManagementComponent,
            create_user_component_1.CreateUserComponent,
            edit_user_component_1.EditUserComponent,
            monitor_chart_component_1.MonitorChartComponent,
            monitor_graph_component_1.MonitorGraphComponent,
            dropdown_url_component_1.dropdownUrlComponent,
            dropdown_search_component_1.dropdownSearchComponent,
            dropdown_check_component_1.dropdownCheckComponent,
            create_scan_page_component_1.CreatePageComponent,
            one_time_page_component_1.OneTimPageComponent,
            single_info_page_component_1.SingleInfoPageComponent,
            user_management_page_component_1.UserManagementPageComponent,
            edit_user_page_component_1.EditUserPageComponent,
            create_user_page_component_1.CreateUserPageComponent,
            monitoring_page_component_1.MonitoringPageComponent
        ],
        providers: [
            auth_service_1.AuthService,
            table_api_service_1.TableApiService
        ],
        bootstrap: [app_component_1.AppComponent]
    }),
    __metadata("design:paramtypes", [])
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map