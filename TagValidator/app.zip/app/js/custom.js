/*----------------------------------------
 bar chart
 ---------------------------------------------*/
var data = {
    labels: ["22/07 2016", "22/07 2016", "22/07 2016", "22/07 2016", "22/07 2016", "22/07 2016", "22/07 2016"],
    datasets: [
        {
            label: '% of pages tracked',
            data: [10, 40, 80, 40, 30, 70, 90],
            backgroundColor: 'transparent',
            borderColor: [
                'rgba(249, 198, 46, 1)'
            ],
            borderWidth: 3
        },
        {
            label: 'Overall data quality',
            data: [20, 40, 60, 80, 70, 90, 40],
            backgroundColor: "rgba(237, 250, 253, 1)",
            borderColor: [
                'rgba(0, 183, 227, 1)'
            ],
            borderWidth: 3
        }
    ]
};
var options = {
    tension: 0.1,
    fullWidth: false,
    responsive: true,
    scales: {
        yAxes: [
            {
                ticks: {
                    max: 100,
                    min: 0,
                    stepSize: 50
                }
            }
        ]
    }
};

    var chartLoad = true;
    $(window).scroll(function () {
        var aTop = $('.chart-display').height();
        if ($(this).scrollTop() >= aTop) {
            if (chartLoad) {
                var ctx = document.getElementById("hChart");
                var hChart = new Chart(ctx, {
                    type: 'line',
                    data: data,
                    options: options
                });
                chartLoad = false;
            }
        }
    });





